import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import imageprocessor.model.IModel;
import imageprocessor.model.Model;
import imageprocessor.Pixel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Class designated for testing the Model.
 */
public abstract class ModelTest {
  protected List<List<Pixel>> pixels;
  protected IModel model;
  protected List<List<Pixel>> pixels2;
  protected List<List<Pixel>> pixels3;
  protected IModel model2;

  protected abstract void init();

  protected List<List<Pixel>> randomGenerator(int width, int height, int maxDepth) {
    List<List<Pixel>> result = new ArrayList<>();

    Random rand = new Random(10);
    for (int i = 0; i < height; i++) {
      List<Pixel> inner = new ArrayList<>();
      for (int j = 0; j < width; j++) {
        inner.add(new Pixel(rand.nextInt(maxDepth),
                rand.nextInt(maxDepth), rand.nextInt(maxDepth)));
      }
      result.add(inner);
    }
    //System.out.println(result);
    return result;
  }

  // test when you override an existing image name in the history map
  @Test
  public void testOverrideHistory() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(1, 2, 3), new Pixel(1, 2, 3));
    List<Pixel> inner2 = Arrays.asList(new Pixel(0, 0, 0), new Pixel(1, 255, 255));
    List<List<Pixel>> dummy = Arrays.asList(inner1, inner2);
    this.model2.addToHistory(dummy, "initialModel");
    assertEquals(dummy, model2.getPixelsFromHistory("initialModel"));
  }

  @Test
  public void testGetDepth() {
    this.init();
    assertEquals(255, this.model2.getDepth());
    assertEquals(255, this.model.getDepth());
  }

  @Test
  public void testConstructor() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(3, 75, 108), new Pixel(60, 151, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 148, 216), new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorException1() { // Invalid width, must be 2.
    List<List<Pixel>> error = new ArrayList<>();
    List<Pixel> innerError = new ArrayList<>();
    List<Pixel> innerError2 = new ArrayList<>();
    innerError.add(new Pixel(1, 2, 3));
    innerError.add(new Pixel(1, 2, 3));
    innerError2.add(new Pixel(1, 2, 3));
    innerError2.add(new Pixel(1, 2, 3));
    error.add(innerError);
    error.add(innerError2);
    IModel model = new Model(error, 3, 2);
  }

  @Test // this test tries to fix the above exception, after the fix, no exception is thrown.
  public void testConstructorNoExceptionThrown() {
    List<List<Pixel>> error = new ArrayList<>();
    List<Pixel> innerError = new ArrayList<>();
    List<Pixel> innerError2 = new ArrayList<>();
    innerError.add(new Pixel(1, 2, 3));
    innerError.add(new Pixel(1, 2, 3));
    innerError.add(new Pixel(1, 2, 3));
    innerError2.add(new Pixel(1, 2, 3));
    innerError2.add(new Pixel(1, 2, 3));
    innerError2.add(new Pixel(1, 2, 3));
    error.add(innerError);
    error.add(innerError2);
    IModel model = new Model(error, 3, 2);
    assertNotNull(model);
  }

  @Test
  public void testBrightenBy() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(53, 125, 158), new Pixel(110, 201, 255));
    List<Pixel> inner2 = Arrays.asList(new Pixel(177, 198, 255), new Pixel(255, 108, 214));
    List<Pixel> inner3 = Arrays.asList(new Pixel(0, 25, 58), new Pixel(10, 101, 191));
    List<Pixel> inner4 = Arrays.asList(new Pixel(77, 98, 166), new Pixel(194, 8, 114));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    List<List<Pixel>> result2 = Arrays.asList(inner3, inner4);
    this.model2.brightenOrDarkenBy(50, "initialModel", "test1");
    assertEquals(result, this.model2.getPixelsFromHistory("test1"));
    this.model2.brightenOrDarkenBy(-50, "initialModel", "test2");
    assertEquals(result2, this.model2.getPixelsFromHistory("test2"));
  }

  @Test
  public void testComponentLuma() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(62, 62, 62), new Pixel(138, 138, 138));
    List<Pixel> inner2 = Arrays.asList(new Pixel(148, 148, 148), new Pixel(105, 105, 105));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("luma", "initialModel", "lumaComp");
    assertEquals(result, this.model2.getPixelsFromHistory("lumaComp"));
  }

  @Test
  public void testComponentIntensity() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(62, 62, 62), new Pixel(150,
            150, 150));
    List<Pixel> inner2 = Arrays.asList(new Pixel(163, 163, 163), new Pixel(155,
            155, 155));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("intensity", "initialModel",
            "intensityComp");
    assertEquals(result, this.model2.getPixelsFromHistory("intensityComp"));
  }


  @Test(expected = IllegalArgumentException.class)
  public void testComponentException1() { // invalid component given
    this.init();
    this.model2.visualizeComponent("val", "initialModel", "invalidImage");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testComponentException2() { // invalid component given
    this.init();
    this.model2.visualizeComponent("red", "initialModel", "invalidImage");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testComponentException3() { // invalid image name given
    this.init();
    this.model2.visualizeComponent("r", "initial", "invalidImageName");
  }

  @Test
  public void testReferenceGetPixelDifferent() {
    this.init();
    IModel model = new Model(this.pixels2, 2, 2);
    assertFalse(model.getPixelsFromHistory("initialModel") == this.pixels2);
    assertTrue(model.getPixelsFromHistory("initialModel").equals(this.pixels2));
  }

  @Test
  public void testComponentValue() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(108, 108, 108), new Pixel(241,
            241, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(216, 216, 216), new Pixel(244,
            244, 244));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("value", "initialModel",
            "valueComp");
    assertEquals(result, this.model2.getPixelsFromHistory("valueComp"));
  }

  @Test
  public void testComponentRed() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(3, 3, 3), new Pixel(60,
            60, 60));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 127, 127), new Pixel(244,
            244, 244));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("r", "initialModel",
            "redComp");
    assertEquals(result, this.model2.getPixelsFromHistory("redComp"));
  }

  @Test
  public void testComponentBlue() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(108, 108, 108), new Pixel(241,
            241, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(216, 216, 216), new Pixel(164,
            164, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("b", "initialModel",
            "blueComp");
    assertEquals(result, this.model2.getPixelsFromHistory("blueComp"));
  }

  @Test
  public void testComponentGreen() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(75, 75, 75), new Pixel(151,
            151, 151));
    List<Pixel> inner2 = Arrays.asList(new Pixel(148, 148, 148), new Pixel(58,
            58, 58));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.model2.visualizeComponent("g", "initialModel",
            "greenComp");
    assertEquals(result, this.model2.getPixelsFromHistory("greenComp"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorExceptionNullArray() {
    this.init();
    IModel model = new Model(null, 2, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorExceptionMTPPM() {
    this.init();
    IModel model = new Model(null, 2, 2);
  }

  @Test
  public void testFlip() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(60, 151, 241), new Pixel(3, 75, 108));
    List<Pixel> inner2 = Arrays.asList(new Pixel(244, 58, 164), new Pixel(127, 148, 216));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    List<Pixel> inner3 = Arrays.asList(new Pixel(3, 75, 108), new Pixel(60, 151, 241));
    List<Pixel> inner4 = Arrays.asList(new Pixel(127, 148, 216), new Pixel(244, 58, 164));
    List<List<Pixel>> result2 = Arrays.asList(inner4, inner3);
    this.model2.flip(true, "initialModel", "test1");
    this.model2.flip(false, "initialModel", "test2");
    assertEquals(result, this.model2.getPixelsFromHistory("test1"));
    assertEquals(result2, this.model2.getPixelsFromHistory("test2"));
    /// assertEquals(result2, this.model2.flip());
  }
}