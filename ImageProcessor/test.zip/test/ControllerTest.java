import org.junit.Test;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import imageprocessor.controller.Controller;
import imageprocessor.controller.IController;
import imageprocessor.InputInteraction;
import imageprocessor.Interaction;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;
import imageprocessor.model.IModel;
import imageprocessor.Pixel;
import imageprocessor.PrintInteraction;
import imageprocessor.view.IView;
import imageprocessor.view.View;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

/**
 * Class designated for testing the Model.
 */
public class ControllerTest {
  EnhancedModel model;
  EnhancedModel model2;
  EnhancedModel enhancedModel1;
  EnhancedModel enhancedModel2;
  IView view;
  Appendable output;
  Interaction[] interactions;

  private void init() {
    List<List<Pixel>> pixels = this.randomGenerator(4, 4, 255);
    output = new StringBuilder();
    this.model = new EnhancedModelImpl(pixels, 4, 4);
    this.view = new View(output);
    model2 = new EnhancedModelImpl(this.randomGenerator(2, 2, 255), 2, 2);
    this.enhancedModel1 = new EnhancedModelImpl();
  }

  private List<List<Pixel>> randomGenerator(int width, int height, int maxDepth) {
    List<List<Pixel>> result = new ArrayList<>();

    Random rand = new Random(10);
    for (int i = 0; i < height; i++) {
      List<Pixel> inner = new ArrayList<>();
      for (int j = 0; j < width; j++) {
        inner.add(new Pixel(rand.nextInt(maxDepth), rand.nextInt(maxDepth),
                rand.nextInt(maxDepth)));
      }
      result.add(inner);
    }
    return result;
  }

  private void createBrokenPPM(String filePath, List<List<Pixel>> pixels, int maxDepth)
          throws IllegalStateException, IllegalArgumentException {
    if (filePath.endsWith("ppm")) {
      OutputStream os;
      File file = new File(filePath);
      try {
        try {
          os = new FileOutputStream(file);
          OutputStreamWriter output = new OutputStreamWriter(os);
          BufferedWriter writer = new BufferedWriter(output);
          writer.write("P3");
          writer.newLine();
          writer.write(pixels.get(0).size() + " ");
          writer.write(pixels.size() + "");
          writer.newLine();
          writer.write(maxDepth + "");
          writer.newLine();
          for (int i = 0; i < pixels.size(); i++) { // rows
            for (int j = 0; j < pixels.get(i).size(); j++) { //cols
              for (int k = 0; k < 3; k++) { // rgb
                writer.write(pixels.get(i).get(j).getComponent(k) + "");
                if (k != 3) {
                  writer.write(" ");
                }
                if (j != pixels.get(0).size() - 1) {
                  writer.write(" ");
                }
              }
            }
            writer.newLine();
          }
          os.flush();
          writer.close();
          os.close();
        } catch (FileNotFoundException f) {
          throw new IllegalArgumentException("Given file not found, make sure path is valid!");
        }
      } catch (IOException s) {
        throw new IllegalStateException("something went wrong!");
      }
    } else {
      throw new IllegalArgumentException("Unsupported file format!");
    }
  }

  @Test
  public void testNewCommand1() {
    this.init();
    Appendable output = new StringBuilder();
    view = new View(output);
    interactions = new Interaction[] {
        new PrintInteraction("Supported user instructions are: \n" +
                    "load file-path destination-name\n" +
                    "save file-path image-name\n" +
                    "flip-horizontal image-name destination-name\n" +
                    "flip-vertical image-name destination-name\n" +
                    "brighten increment image-name destination-name\n" +
                    "red-component image-name destination-name\n" +
                    "blue-component image-name destination-name\n" +
                    "green-component image-name destination-name\n" +
                    "value-component image-name destination-name\n" +
                    "intensity-component image-name destination-name\n" +
                    "luma-component image-name destination-name\n" +
                    "blur image-name destination-name\n" +
                    "sharpen image-name destination-name\n" +
                    "luma image-name destination-name\n" +
                    "sepia image-name destination-name\n" +
                    "q/Q/quit (quit the program)"),
        new InputInteraction("load Images/manhattan.png man "),
        new PrintInteraction("Successfully loaded the image!"),
        new InputInteraction("blur man manBlur "),
        new InputInteraction("sharpen man manSharp "),
        new InputInteraction("sepia man manSepia "),
        new InputInteraction("luma man manLuma "),
        new InputInteraction("save res/manLumaBMP.bmp manLuma "),
        new PrintInteraction("Successfully saved the image!"),
        new InputInteraction("quitty "),
        new PrintInteraction("Unsupported command given!"),
        new InputInteraction("quit"),
        new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }

  @Test
  public void testLoadPPMSaveJPG() {
    this.init();
    Appendable ouput = new StringBuilder();
    view = new View(ouput);
    interactions = new Interaction[] {
        new PrintInteraction("Supported user instructions are: \n" +
                    "load file-path destination-name\n" +
                    "save file-path image-name\n" +
                    "flip-horizontal image-name destination-name\n" +
                    "flip-vertical image-name destination-name\n" +
                    "brighten increment image-name destination-name\n" +
                    "red-component image-name destination-name\n" +
                    "blue-component image-name destination-name\n" +
                    "green-component image-name destination-name\n" +
                    "value-component image-name destination-name\n" +
                    "intensity-component image-name destination-name\n" +
                    "luma-component image-name destination-name\n" +
                    "blur image-name destination-name\n" +
                    "sharpen image-name destination-name\n" +
                    "luma image-name destination-name\n" +
                    "sepia image-name destination-name\n" +
                    "q/Q/quit (quit the program)\n" +
                    "Successfully loaded the image!\n" +
                    "Successfully saved the image!\n" +
                    "ImageProcessor quit! Thank you for your time."),
        new InputInteraction("load Images/Koala.ppm ko save res/KoalaJPGJPG2.jpg ko q"),
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }

  @Test
  public void testReadPPMsavePNGAndLoadAgain() {
    this.init();
    Readable input = new StringReader("load Images/initFlippedPNG.png init q");
    List<Pixel> inner1 = Arrays.asList( new Pixel(3, 75, 108),
            new Pixel(60, 151, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 148, 216),
            new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(result, model2.getPixelsFromHistory("init"));
  }

  @Test
  public void testReadPPMsaveBMPAndLoadAgain() {
    this.init();
    Readable input = new StringReader("load Images/initFlippedBMP.bmp init q");
    List<Pixel> inner1 = Arrays.asList( new Pixel(3, 75, 108),
            new Pixel(60, 151, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 148, 216),
            new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(result, model2.getPixelsFromHistory("init"));
  }

  @Test
  public void testReadPPMsaveJPGAndLoadAgain() {
    this.init();
    Readable input = new StringReader("load Images/initFlippedBMP.bmp init" +
            " save Images/initFlippedJPG.jpg init load Images/initFlippedJPG.jpg initJPG q");
    List<Pixel> inner1 = Arrays.asList( new Pixel(70, 57, 139),
            new Pixel(113, 100, 182));
    List<Pixel> inner2 = Arrays.asList(new Pixel(133, 120, 202),
            new Pixel(132, 119,201));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(result.size(), model2.getPixelsFromHistory("initJPG").size());
    assertEquals(result, model2.getPixelsFromHistory("initJPG"));
  }

  @Test
  public void testReadPNGAndPPMAndComparePixels() {
    this.init();
    Readable input = new StringReader("load Images/initFlippedPNG.png initPNG" +
            " load Images/initFlipped.ppm initPPM q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(model2.getPixelsFromHistory("initPNG"),
            model2.getPixelsFromHistory("initPPM"));
  }

  @Test
  public void testInvalidPathSave() {
    this.init();
    Readable input = new StringReader("load res/randomImage.ppm " +
            "rand save Images4/rand.png rand q");
    output = new StringBuilder();
    view = new View(output);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals("Supported user instructions are: \n" +
            "load file-path destination-name\n" +
            "save file-path image-name\n" +
            "flip-horizontal image-name destination-name\n" +
            "flip-vertical image-name destination-name\n" +
            "brighten increment image-name destination-name\n" +
            "red-component image-name destination-name\n" +
            "blue-component image-name destination-name\n" +
            "green-component image-name destination-name\n" +
            "value-component image-name destination-name\n" +
            "intensity-component image-name destination-name\n" +
            "luma-component image-name destination-name\n" +
            "blur image-name destination-name\n" +
            "sharpen image-name destination-name\n" +
            "luma image-name destination-name\n" +
            "sepia image-name destination-name\n" +
            "q/Q/quit (quit the program)\n" +
            "Successfully loaded the image!\n" +
            "Some IO issue occurred, make sure the file path is valid!\n" +
            "ImageProcessor quit! Thank you for your time.\n", output.toString());
  }

  @Test
  public void testInvalidPathLoad() {
    this.init();
    Readable input = new StringReader("load Images4/random.png rand q");
    output = new StringBuilder();
    view = new View(output);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals("Supported user instructions are: \n" +
            "load file-path destination-name\n" +
            "save file-path image-name\n" +
            "flip-horizontal image-name destination-name\n" +
            "flip-vertical image-name destination-name\n" +
            "brighten increment image-name destination-name\n" +
            "red-component image-name destination-name\n" +
            "blue-component image-name destination-name\n" +
            "green-component image-name destination-name\n" +
            "value-component image-name destination-name\n" +
            "intensity-component image-name destination-name\n" +
            "luma-component image-name destination-name\n" +
            "blur image-name destination-name\n" +
            "sharpen image-name destination-name\n" +
            "luma image-name destination-name\n" +
            "sepia image-name destination-name\n" +
            "q/Q/quit (quit the program)\n" +
            "File path was invalid!\n" +
            "ImageProcessor quit! Thank you for your time.\n",output.toString());
  }

  @Test
  public void testReadPPMAndPNGAndComparePixels() {
    this.init();
    Readable input = new StringReader("load res/randomImage.ppm" +
            " randPPM save Images/randomImagePNG.png " +
            "randPPM load Images/randomImagePNG.png randPNG q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(model2.getPixelsFromHistory("randPPM"),
            model2.getPixelsFromHistory("randPNG"));
  }

  @Test // jpg compresses the data and loses some of it, which results in slightly different colors
  public void testReadJPGAndPNGAndComparePixels() {
    this.init();
    Readable input = new StringReader("load Images/randomImagePNG.png randPNG" +
            " save Images/randomImageJPG.jpeg randPNG load Images/randomImageJPG.jpeg randJPG q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertNotEquals(model2.getPixelsFromHistory("randJPG"),
            model2.getPixelsFromHistory("randPNG"));
  }

  @Test
  public void testReadBMPAndPPMAndComparePixels() {
    this.init();
    Readable input = new StringReader("load res/randomImage.ppm rand" +
            " save Images/randomImageBMP.bmp rand load Images/randomImageBMP.bmp randBMP q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(model2.getPixelsFromHistory("rand"),
            model2.getPixelsFromHistory("randBMP"));
  }

  @Test
  public void testReadBMPAndPNGAndComparePixels() {
    this.init();
    Readable input = new StringReader("load Images/randomImageBMP.bmp randBMP" +
            " load Images/randomImagePNG.png randPNG q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertEquals(model2.getPixelsFromHistory("randPNG"),
            model2.getPixelsFromHistory("randBMP"));
  }

  @Test
  public void testMockModelAllCommands() {
    this.init();
    Readable input = new StringReader("load Images/initFlipped.png init " +
            "flip-horizontal init initFlipHorz flip-vertical init initFlipVert flip " +
            "brighten 20 init initBright luma-component init initLuma " +
            "red-component init initRed value-component init initVal " +
            "blur init initBlur sharpen init initSharp " +
            "luma init initLuma sepia init initSepia " +
            "some invalid stuff that wont be read INVALID INVALID INVALID INVALID INVALID " +
            "quit");
    Appendable output = new StringBuilder();
    EnhancedModel model = new MockModel(output);
    IController controller = new Controller(model, view, input);
    controller.goImageProcessor();
    assertEquals("Function: flip -> true, init, initFlipHorz" +
            "Function: flip -> false, init, initFlipVert" +
            "Function: brightenOrDarkenBy -> 20, init, initBright" +
            "Function: visualizeComponent -> luma, init, initLuma" +
            "Function: visualizeComponent -> r, init, initRed" +
            "Function: visualizeComponent -> value, init, initVal" +
            "Function: filter -> blur, init, initBlur" +
            "Function: filter -> sharpen, init, initSharp" +
            "Function: colorTransform -> luma, init, initLuma" +
            "Function: colorTransform -> sepia, init, initSepia", output.toString());
  }

  @Test
  public void testConfirmJPGNotEqualsJPEG() {
    this.init();
    Readable input = new StringReader("load Images/randomImageJPG.jpeg randJPEG" +
            " save Images/randomImageJPG3.jpg randJPEG load Images/randomImageJPG3.jpg randJPG q");
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    assertNotEquals(model2.getPixelsFromHistory("randJPG"),
            model2.getPixelsFromHistory("randJPEG"));
  }

  @Test
  public void testLoadPNG() {
    this.init();
    Appendable output = new StringBuilder();
    view = new View(output);
    Readable input = new StringReader("load Images/manhattan.png spiderman\n" +
            " sepia spiderman sepia save Images/manhattanSepia.png sepia q");
    IController controller = new Controller(enhancedModel1, view, input);
    controller.goImageProcessor();
    assertEquals("Supported user instructions are: \n" +
            "load file-path destination-name\n" +
            "save file-path image-name\n" +
            "flip-horizontal image-name destination-name\n" +
            "flip-vertical image-name destination-name\n" +
            "brighten increment image-name destination-name\n" +
            "red-component image-name destination-name\n" +
            "blue-component image-name destination-name\n" +
            "green-component image-name destination-name\n" +
            "value-component image-name destination-name\n" +
            "intensity-component image-name destination-name\n" +
            "luma-component image-name destination-name\n" +
            "blur image-name destination-name\n" +
            "sharpen image-name destination-name\n" +
            "luma image-name destination-name\n" +
            "sepia image-name destination-name\n" +
            "q/Q/quit (quit the program)\n" +
            "Successfully loaded the image!\n" +
            "Successfully saved the image!\n" +
            "ImageProcessor quit! Thank you for your time.\n", output.toString());
  }


  @Test
  public void testGenerateBrokenPPMAndTryLoading() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("load /Users/omarshair/oodHW/ImageProcessor/Images/error.ppm" +
                    " whaetevr\n"),
      new PrintInteraction("Invalid ppm file given, more elements than needed!"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    List<Pixel> inner1 = Arrays.asList(new Pixel(1, 2, 3));
    List<Pixel> inner2 = Arrays.asList(new Pixel(1, 2, 3), new Pixel(2, 3, 1));
    List<List<Pixel>> error = Arrays.asList(inner1, inner2);
    this.createBrokenPPM("/Users/omarshair/oodHW/ImageProcessor/Images/error.ppm",
            error, 255);
    assertEquals(0, this.testRun(model2, interactions));
  }

  private int testRun(EnhancedModel model, Interaction... interactions)
          throws IllegalStateException, IllegalArgumentException {
    StringBuilder actualOutput = new StringBuilder();
    IView viewer = new View(actualOutput);
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();
    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }
    Reader input = new StringReader(fakeUserInput.toString());
    IController controller = new Controller(model, viewer, input);
    try {
      controller.goImageProcessor();
      assertEquals(expectedOutput.toString(), actualOutput.toString());
      return 0;
    } catch (IllegalStateException e) {
      throw e;
    } catch (IllegalArgumentException s) {
      throw s;
    }
  }

  @Test(expected = IllegalStateException.class)
  public void testBrokenViewGivenToController() {
    this.init();
    Readable inputs = new StringReader("load q");
    Appendable brokenOutput = new BrokenAppendable();
    IView view = new View(brokenOutput);
    IController controller = new Controller(model2, view, inputs);
    controller.goImageProcessor();
  }

  @Test(expected = IllegalStateException.class)
  public void testBrokenViewGivenToController2() {
    this.init();
    Readable inputs = new StringReader("q");
    Appendable brokenOutput = new BrokenAppendable();
    IView view = new View(brokenOutput);
    IController controller = new Controller(model2, view, inputs);
    controller.goImageProcessor();
  }

  @Test(expected = IllegalStateException.class)
  public void testNoMoreInputs() {
    this.init();
    interactions = new Interaction[]{
      new InputInteraction("load this and that and " +
                    "that and this and thus, that"),
      new PrintInteraction("")
    };
    this.testRun(model2, interactions);
  }

  @Test
  public void testInvalidCommand() {
    this.init();
    interactions = new Interaction[] {
      new PrintInteraction("Supported user instructions are: \n" +
                    "load file-path destination-name\n" +
                    "save file-path image-name\n" +
                    "flip-horizontal image-name destination-name\n" +
                    "flip-vertical image-name destination-name\n" +
                    "brighten increment image-name destination-name\n" +
                    "red-component image-name destination-name\n" +
                    "blue-component image-name destination-name\n" +
                    "green-component image-name destination-name\n" +
                    "value-component image-name destination-name\n" +
                    "intensity-component image-name destination-name\n" +
                    "luma-component image-name destination-name\n" +
                    "blur image-name destination-name\n" +
                    "sharpen image-name destination-name\n" +
                    "luma image-name destination-name\n" +
                    "sepia image-name destination-name\n" +
                    "q/Q/quit (quit the program)"),
      new InputInteraction("invalid\n"),
      new PrintInteraction("Unsupported command given!"),
      new InputInteraction("lum grey \n"),
      new PrintInteraction("Unsupported command given!\n" +
                    "Unsupported command given!"),
      new InputInteraction("Q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }



  @Test
  public void testLoadingPNG() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("load Images/spiderman.png spiderman "),
      new PrintInteraction("Successfully loaded the image!"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }


  @Test
  public void testOpenFile() {
    this.init();
    try {
      Scanner scan = new Scanner(new FileInputStream("/Users/omarshair/oodHW/ImageProcessor"
              + "/Images/test2.ppm"));
      StringBuilder builder = new StringBuilder();
      //read the file line by line, and populate a string. This will throw away any comment lines
      while (scan.hasNext()) {
        builder.append(scan.next() + System.lineSeparator());
      }
      assertEquals("P3\n" +
              "2\n" +
              "2\n" +
              "255\n" +
              "60\n" +
              "151\n" +
              "241\n" +
              "3\n" +
              "75\n" +
              "108\n" +
              "244\n" +
              "58\n" +
              "164\n" +
              "127\n" +
              "148\n" +
              "216\n", builder.toString());
    } catch (FileNotFoundException e) {
      fail();
    }
  }

  @Test
  public void testCreatePPMFile() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomImage.ppm" +
                    " initialModel "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("flip-vertical initialModel randomFlipped "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/" +
                    "randomVertical.ppm randomFlipped "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("flip-horizontal initialModel randomHorizontal "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/" +
                    "randomHorizontal.ppm randomHorizontal "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("brighten 60 initialModel randomBright "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomBright.ppm"
                    + " randomBright "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("brighten -60 initialModel randomDark "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomDark.ppm" +
                    " randomDark "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("luma-component initialModel randomLuma "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomLuma.ppm" +
                    " randomLuma "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("value-component initialModel randomValue "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomValue.ppm" +
                    " randomValue "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("intensity-component initialModel randomIntensity "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/" +
                    "randomIntensity.ppm randomIntensity "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("red-component initialModel randomRed "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomRed.ppm" +
                    " randomRed "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("blue-component initialModel randomBlue "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomBlue.ppm" +
                    " randomBlue "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("green-component initialModel randomGreen "),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/res/randomGreen.ppm" +
                    " randomGreen "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    List<List<Pixel>> random = this.randomGenerator(6, 8, 255);
    EnhancedModel model = new EnhancedModelImpl(random, 6, 8);
    this.testRun(model, interactions);
    assertNotNull(model);
  }

  @Test
  public void testControllerSaving() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/Images/random.ppm" +
              " initialModel\n"),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model, interactions);
    assertNotNull(model);
  }

  @Test
  public void testSave2() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("save /Users/omarshair/oodHW/ImageProcessor/Images/random2.ppm" +
                    " initialModel\n"),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }

  @Test
  public void testFlip() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("flip-horizontal initialModel flippy "),
      new InputInteraction("flip-vertical flippy flippy "),
      new InputInteraction("save " +
                    "/Users/omarshair/oodHW/ImageProcessor/Images/Flippy.ppm flippy "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("Q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertNotNull(model2);
  }

  @Test
  public void testIsSameArrayPixelsKoalaProvidedKoala() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("load /Users/omarshair/oodHW/ImageProcessor/" +
                    "Images/Koala.ppm koala\n"),
      new PrintInteraction("Successfully loaded the image!"),
      new InputInteraction("flip-horizontal koala flippyKoala "),
      new InputInteraction("flip-horizontal flippyKoala flippyKoala "),
      new InputInteraction("save " +
                    "/Users/omarshair/oodHW/ImageProcessor/Images/FlippyKoala.ppm flippyKoala "),
      new PrintInteraction("Successfully saved the image!"),
      new InputInteraction("Q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model2, interactions);
    assertEquals(this.model2.getPixelsFromHistory("koala"),
            this.model2.getPixelsFromHistory("flippyKoala"));
  }

  @Test
  public void testBrighten() {
    this.init();
    interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
             "load file-path destination-name\n" +
             "save file-path image-name\n" +
             "flip-horizontal image-name destination-name\n" +
             "flip-vertical image-name destination-name\n" +
             "brighten increment image-name destination-name\n" +
             "red-component image-name destination-name\n" +
             "blue-component image-name destination-name\n" +
             "green-component image-name destination-name\n" +
             "value-component image-name destination-name\n" +
             "intensity-component image-name destination-name\n" +
             "luma-component image-name destination-name\n" +
             "blur image-name destination-name\n" +
             "sharpen image-name destination-name\n" +
             "luma image-name destination-name\n" +
             "sepia image-name destination-name\n" +
             "q/Q/quit (quit the program)"),
      new InputInteraction("brighten -100 initialModel bright "),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    List<Pixel> inner1 = Arrays.asList(new Pixel(0, 0, 8),
            new Pixel(0, 51, 141));
    List<Pixel> inner2 = Arrays.asList(new Pixel(27, 48, 116),
            new Pixel(144, 0, 64));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.testRun(model2, interactions);
    assertEquals(result, model2.getPixelsFromHistory("bright"));
  }



  @Test
  public void testReadingTheFlippySavedImage() {
    this.init();
    Appendable ouput = new StringBuilder();
    Readable input = new StringReader("load /Users/omarshair/oodHW/ImageProcessor/" +
            "Images/Flippy.ppm flippy\n q");
    IView view = new View(output);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    List<Pixel> inner1 = Arrays.asList(new Pixel(60, 151, 241),
            new Pixel(3, 75, 108));
    List<Pixel> inner2 = Arrays.asList(new Pixel(244, 58, 164),
            new Pixel(127, 148, 216));
    List<List<Pixel>> result = Arrays.asList(inner2, inner1);
    assertEquals(result, model2.getPixelsFromHistory("flippy"));
  }

  @Test
  public void testReadingTheRandom2SavedImage() {
    this.init();
    Appendable ouput = new StringBuilder();
    Readable input = new StringReader("load /Users/omarshair/oodHW/ImageProcessor/" +
            "Images/random2.ppm random2\n q");
    IView view = new View(output);
    IController controller = new Controller(model2, view, input);
    controller.goImageProcessor();
    List<Pixel> inner1 = Arrays.asList(new Pixel(3, 75, 108),
            new Pixel(60, 151, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 148, 216),
            new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    assertEquals(result, model2.getPixelsFromHistory("random2"));
  }


  @Test
  public void testMockModel() {
    this.init();
    Appendable output = new StringBuilder();
    Readable inputs = new StringReader("s");
    EnhancedModel model = new MockModel(output);
    IController controller = new Controller(model, view, inputs);
    assertNotNull(model);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMockModelException() {
    IModel model = new MockModel(null);
  }

  @Test
  public void testQuitInstant() {
    this.init();
    Interaction[] interactions = new Interaction[]{
      new PrintInteraction("Supported user instructions are: \n" +
              "load file-path destination-name\n" +
              "save file-path image-name\n" +
              "flip-horizontal image-name destination-name\n" +
              "flip-vertical image-name destination-name\n" +
              "brighten increment image-name destination-name\n" +
              "red-component image-name destination-name\n" +
              "blue-component image-name destination-name\n" +
              "green-component image-name destination-name\n" +
              "value-component image-name destination-name\n" +
              "intensity-component image-name destination-name\n" +
              "luma-component image-name destination-name\n" +
              "blur image-name destination-name\n" +
              "sharpen image-name destination-name\n" +
              "luma image-name destination-name\n" +
              "sepia image-name destination-name\n" +
              "q/Q/quit (quit the program)"),
      new InputInteraction("q"),
      new PrintInteraction("ImageProcessor quit! Thank you for your time.")
    };
    this.testRun(model, interactions);
    assertNotNull(model);
  }

  @Test
  public void testMockModelNoInputsExceptQuit() {
    Appendable outputModel = new StringBuilder();
    Readable input = new StringReader("Q");
    EnhancedModel mock = new MockModel(outputModel);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("", outputModel.toString());
  }


  @Test
  public void testMockModelLoad() {
    Appendable outputModel = new StringBuilder();
    Readable input = new StringReader("load /Users/omarshair/oodHW/" +
            "ImageProcessor/Images/Koala.ppm Koala\n quit");
    EnhancedModel mock = new MockModel(outputModel);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: addToHistory -> imageName: Koala",
            outputModel.toString());
  }

  @Test
  public void testMockModelSave() {
    this.init();
    Appendable outputModel = new StringBuilder();
    Readable input = new StringReader("save /Users/omarshair/oodHW/" +
            "ImageProcessor/Images/Koala420.ppm initialModel\n quit");
    EnhancedModel mock = new MockModel(outputModel);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    try {
      controller.goImageProcessor();
    }

    catch (NullPointerException n) { // because mockmodel's getPixelsFromHistory returns null
      assertEquals("Function: getPixelsFromHistory -> initialModel",
              outputModel.toString());
    }

  }

  @Test
  public void testMockModelBrighten() {
    this.init();
    Appendable outputModel = new StringBuilder();
    Readable input = new StringReader("save /Users/omarshair/oodHW/" +
            "ImageProcessor/Images/Koala420.ppm initialModel\n quit");
    EnhancedModel mock = new MockModel(outputModel);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    try {
      controller.goImageProcessor();
    }

    catch (NullPointerException n) {
      assertEquals("Function: getPixelsFromHistory -> initialModel",
              outputModel.toString());
    }

  }

  @Test
  public void testMockFlip() {
    this.init();
    Appendable ouptput = new StringBuilder();
    Readable input = new StringReader("flip-horizontal initialModel flippy" +
            " flip-vertical intialModel flippyVertc q");
    EnhancedModel mock = new MockModel(ouptput);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: flip -> true, initialModel," +
            " flippyFunction: flip -> false, intialModel, flippyVertc", ouptput.toString());
  }

  @Test
  public void testMockComponent1() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("value-component initialModel val q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> value, initialModel, val",
            output.toString());
  }

  @Test
  public void testMockComponent2() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("luma-component initialModel lum q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> luma, initialModel, lum",
            output.toString());
  }

  @Test
  public void testMockComponent3() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("intensity-component initialModel int q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> intensity, initialModel, int",
            output.toString());
  }

  @Test
  public void testMockComponent4() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("red-component initialModel red q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> r, initialModel, red",
            output.toString());
  }

  @Test
  public void testMockComponent5() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("green-component initialModel green q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> g, initialModel, green",
            output.toString());
  }

  @Test
  public void testMockComponent6() {
    this.init();
    Appendable output = new StringBuilder();
    Readable input = new StringReader("blue-component initialModel blt q");
    EnhancedModel mock = new MockModel(output);
    IView view = new View(new StringBuilder());
    IController controller = new Controller(mock, view, input);
    controller.goImageProcessor();
    assertEquals("Function: visualizeComponent -> b, initialModel, blt",
            output.toString());
  }

  @Test
  public void testGenerateBrokenPPMInvalidDepthAndTryReading() {
    this.init();
    Readable inputs = new StringReader("load /Users/omarshair/" +
            "oodHW/ImageProcessor/Images/broken.ppm" +
            " broken q");
    List<List<Pixel>> brokenPixels = this.randomGenerator(2, 2, 300);
    this.createBrokenPPM("/Users/omarshair/oodHW/ImageProcessor/Images/broken.ppm",
            brokenPixels, 255);
    Appendable output = new StringBuilder();
    IView view = new View(output);
    IController controller = new Controller(model2, view, inputs);
    controller.goImageProcessor();
    assertEquals("Supported user instructions are: \n" +
            "load file-path destination-name\n" +
            "save file-path image-name\n" +
            "flip-horizontal image-name destination-name\n" +
            "flip-vertical image-name destination-name\n" +
            "brighten increment image-name destination-name\n" +
            "red-component image-name destination-name\n" +
            "blue-component image-name destination-name\n" +
            "green-component image-name destination-name\n" +
            "value-component image-name destination-name\n" +
            "intensity-component image-name destination-name\n" +
            "luma-component image-name destination-name\n" +
            "blur image-name destination-name\n" +
            "sharpen image-name destination-name\n" +
            "luma image-name destination-name\n" +
            "sepia image-name destination-name\n" +
            "q/Q/quit (quit the program)\n" +
            "Given ppm file is invalid.\n" +
            "ImageProcessor quit! Thank you for your time.\n", output.toString());
  }

  @Test
  public void testGenerateBrokenPPMInvalidDimesionsAndTryReading() {
    this.init();
    Readable inputs = new StringReader("load /Users/omarshair/" +
            "oodHW/ImageProcessor/Images/broken2.ppm" +
            " broken q");
    List<List<Pixel>> pixels = this.randomGenerator(2, 4, 255);
    List<List<Pixel>> brokenPixels =
            Arrays.asList(Arrays.asList(pixels.get(0).get(0)), pixels.get(1));
    this.createBrokenPPM("/Users/omarshair/oodHW/ImageProcessor/Images/broken2.ppm",
            brokenPixels, 255);
    Appendable output = new StringBuilder();
    IView view = new View(output);
    IController controller = new Controller(model2, view, inputs);
    controller.goImageProcessor();
    assertEquals("Supported user instructions are: \n" +
            "load file-path destination-name\n" +
            "save file-path image-name\n" +
            "flip-horizontal image-name destination-name\n" +
            "flip-vertical image-name destination-name\n" +
            "brighten increment image-name destination-name\n" +
            "red-component image-name destination-name\n" +
            "blue-component image-name destination-name\n" +
            "green-component image-name destination-name\n" +
            "value-component image-name destination-name\n" +
            "intensity-component image-name destination-name\n" +
            "luma-component image-name destination-name\n" +
            "blur image-name destination-name\n" +
            "sharpen image-name destination-name\n" +
            "luma image-name destination-name\n" +
            "sepia image-name destination-name\n" +
            "q/Q/quit (quit the program)\n" +
            "Invalid ppm file given, more elements than needed!\n" +
            "ImageProcessor quit! Thank you for your time.\n", output.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorException1() {
    this.init();
    IController controller = new Controller(model, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorException2() {
    this.init();
    IController controller = new Controller(null, view);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorException3() {
    this.init();
    IController controller = new Controller(null, view, new StringReader(""));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorException4() {
    this.init();
    IController controller = new Controller(model, view, null);
  }
}