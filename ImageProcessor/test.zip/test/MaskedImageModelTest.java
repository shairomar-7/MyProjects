import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import imageprocessor.Pixel;
import imageprocessor.model.MaskedImageModel;
import imageprocessor.model.EnhancedModel;

import static org.junit.Assert.assertEquals;

/**
 * The tester class for the DoubleEnhancedModel class.
 */
public class MaskedImageModelTest {

  EnhancedModel dem;
  List<List<Pixel>> pixels;

  @Before
  public void init() {
    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(54, 12, 129), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 89, 54),
            new Pixel(54, 12, 234), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(255, 0, 15));
    List<Pixel> p3 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(54, 171, 185), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(19, 0, 15));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(54, 67, 131), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(180, 115, 235), new Pixel(19, 86, 99),
            new Pixel(43, 54, 243), new Pixel(255, 200, 15));
    this.pixels = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem = new MaskedImageModel(this.pixels, 5, 5);

  }

  @Test
  public void testGetDepth() {
    assertEquals(255, this.dem.getDepth());
  }

  @Test
  public void testGetPixelsFromHistory() {
    assertEquals(this.pixels, this.dem.getPixelsFromHistory("initialModel"));
  }

  @Test
  public void testAddToHistory() {
    assertEquals(this.pixels, this.dem.getPixelsFromHistory("initialModel"));
    this.dem.addToHistory(this.pixels, "dest");
    assertEquals(this.pixels, this.dem.getPixelsFromHistory( "dest"));
  }

  @Test
  public void testVisualizeComponent() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(43, 43, 43),
            new Pixel(54, 54, 54), new Pixel(43, 43, 43),
            new Pixel(43, 43, 43), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 43, 43),
            new Pixel(54, 54, 54), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(255, 255, 255));
    List<Pixel> p3 = Arrays.asList(new Pixel(43, 43, 43),
            new Pixel(54, 171, 185), new Pixel(43, 43, 43),
            new Pixel(43, 43, 43), new Pixel(19, 19, 19));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(54, 54, 54), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(43, 43, 43),
            new Pixel(180, 115, 235), new Pixel(19, 19, 19),
            new Pixel(43, 43, 43), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.visualizeComponent("r",
            "initialModel", "initialRed");
    assertEquals(result, this.dem.getPixelsFromHistory("initialRed"));
  }


  @Test
  public void testBrighten() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(73, 255, 84),
            new Pixel(84, 42, 159), new Pixel(73, 116, 130),
            new Pixel(73, 84, 42), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(73, 119, 84),
            new Pixel(84, 42, 255), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(255, 30, 45));
    List<Pixel> p3 = Arrays.asList(new Pixel(73, 255, 84),
            new Pixel(54, 171, 185), new Pixel(73, 116, 130),
            new Pixel(73, 84, 42), new Pixel(49, 30, 45));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(84, 97, 161), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(73, 255, 84),
            new Pixel(180, 115, 235), new Pixel(49, 116, 129),
            new Pixel(73, 84, 255), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.brightenOrDarkenBy(30,
            "initialModel", "initialBrighten");
    assertEquals(result, this.dem.getPixelsFromHistory("initialBrighten"));
  }

  @Test
  public void testDarken() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(13, 204, 24),
            new Pixel(24, 0, 99), new Pixel(13, 56, 70),
            new Pixel(13, 24, 0), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(13, 59, 24),
            new Pixel(24, 0, 204), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(225, 0, 0));
    List<Pixel> p3 = Arrays.asList(new Pixel(13, 204, 24),
            new Pixel(54, 171, 185), new Pixel(13, 56, 70),
            new Pixel(13, 24, 0), new Pixel(0, 0, 0));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(24, 37, 101), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(13, 204, 24),
            new Pixel(180, 115, 235), new Pixel(0, 56, 69),
            new Pixel(13, 24, 213), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.brightenOrDarkenBy(-30,
            "initialModel", "initialDarken");
    assertEquals(result, this.dem.getPixelsFromHistory("initialDarken"));
  }

  @Test
  public void testBlur() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(26, 71, 51),
            new Pixel(42, 63, 90), new Pixel(53, 73, 80),
            new Pixel(70, 94, 74), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(35, 93, 75),
            new Pixel(60, 104, 136), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(100, 63, 59));
    List<Pixel> p3 = Arrays.asList(new Pixel(42, 125, 72),
            new Pixel(54, 171, 185), new Pixel(95, 117, 121),
            new Pixel(111, 110, 79), new Pixel(92, 60, 32));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(93, 128, 123), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(49, 106, 57),
            new Pixel(180, 115, 235), new Pixel(74, 66, 117),
            new Pixel(94, 89, 107), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.filter("blur", "initialModel", "initialBlur");
    assertEquals(result, this.dem.getPixelsFromHistory("initialBlur"));
  }

  @Test
  public void testSharpen() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(94, 72, 198),
            new Pixel(107, 211, 214), new Pixel(202, 141, 201),
            new Pixel(212, 255, 255), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(92, 205, 255),
            new Pixel(180, 255, 255), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(39, 35, 41));
    List<Pixel> p3 = Arrays.asList(new Pixel(142, 255, 255),
            new Pixel(54, 171, 185), new Pixel(255, 140, 162),
            new Pixel(225, 134, 0), new Pixel(103, 46, 0));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(255, 255, 255), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(250, 190, 246),
            new Pixel(180, 115, 235), new Pixel(255, 157, 255),
            new Pixel(255, 255, 94), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.filter("sharpen", "initialModel", "initialSharpen");
    assertEquals(result, this.dem.getPixelsFromHistory("initialSharpen"));
  }

  @Test
  public void testSepia() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(207, 184, 143),
            new Pixel(54, 48, 37), new Pixel(101, 90, 70),
            new Pixel(60, 54, 42), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(95, 85, 66),
            new Pixel(74, 66, 51), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(103, 91, 71));
    List<Pixel> p3 = Arrays.asList(new Pixel(207, 184, 143),
            new Pixel(54, 171, 185), new Pixel(101, 90, 70),
            new Pixel(60, 54, 42), new Pixel(10, 9, 7));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(97, 86, 67), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(207, 184, 143),
            new Pixel(180, 115, 235), new Pixel(92, 82, 64),
            new Pixel(104, 92, 72), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.colorTransform("sepia", "initialModel", "initialSepia");
    assertEquals(result, this.dem.getPixelsFromHistory("initialSepia"));
  }

  @Test
  public void testLuma() {
    List<List<Pixel>> result = new ArrayList<>();
    List<Pixel> p1 = Arrays.asList(new Pixel(180, 180, 180),
            new Pixel(29, 29, 29), new Pixel(77, 77, 77),
            new Pixel(48, 48, 48), new Pixel(89, 200, 240));
    List<Pixel> p2 = Arrays.asList(new Pixel(76, 76, 76),
            new Pixel(36, 36, 36), new Pixel(142, 220, 100),
            new Pixel(144, 255, 178), new Pixel(55, 55, 55));
    List<Pixel> p3 = Arrays.asList(new Pixel(180, 180, 180),
            new Pixel(54, 171, 185), new Pixel(77, 77, 77),
            new Pixel(48, 48, 48), new Pixel(5, 5, 5));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(68, 68, 68), new Pixel(234, 54, 100),
            new Pixel(154, 199, 200), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(180, 180, 180),
            new Pixel(180, 115, 235), new Pixel(72, 72, 72),
            new Pixel(65, 65, 65), new Pixel(255, 200, 15));
    result = Arrays.asList(p1, p2, p3, p4, p5);
    this.dem.colorTransform("luma", "initialModel", "initialLuma");
    assertEquals(result, this.dem.getPixelsFromHistory("initialLuma"));
  }
}