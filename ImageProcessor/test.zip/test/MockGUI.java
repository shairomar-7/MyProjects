import java.awt.image.WritableRenderedImage;
import java.io.IOException;
import java.util.Map;

import imageprocessor.controller.Features;
import imageprocessor.view.IViewGUI;


/**
 * A mock version of the GUI. Makes sure every method is producing the correct output.
 */
public class MockGUI implements IViewGUI {
  private final Appendable output;

  protected MockGUI(Appendable out) {
    output = out;
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.output.append(message + "\n");
  }

  @Override
  public void setImage(WritableRenderedImage image) {
    try {
      renderMessage("Function: setImage, Image properties: " + " width: "
              + image.getWidth() + ", height: " + image.getHeight());
    }
    catch (IOException e) {
      throw new IllegalStateException("Yo, something went wrong!");
    }
  }

  @Override
  public void addFeatures(Features features) {
    try {
      renderMessage("Function: addFeatures");
    }
    catch (IOException e) {
      throw new IllegalStateException("Hmm something went wrong!");
    }
  }

  @Override
  public void showHistogram(Map<Integer, Integer>[] map) {
    try {
      renderMessage("Function: showHistogram; map size: " + map.length);
    }
    catch (IOException e) {
      throw new IllegalStateException("Hmm something went wrong!");
    }
  }
}
