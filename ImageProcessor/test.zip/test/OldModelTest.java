
import imageprocessor.model.Model;

/**
 * Tester class for the Model class. Extension
 * of the abstract ModelTest class.
 */
public class OldModelTest extends ModelTest {

  @Override
  protected void init() {
    pixels = this.randomGenerator(5, 5, 255);
    model = new Model(pixels, 5, 5);
    this.pixels2 = this.randomGenerator(2, 2, 255);
    this.model2 = new Model(pixels2, 2, 2);
  }
}
