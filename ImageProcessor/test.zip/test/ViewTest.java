import org.junit.Test;

import java.io.IOException;
import imageprocessor.view.IView;
import imageprocessor.view.View;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Class designated for testing the view component of the Image Processor.
 */
public class ViewTest {
  Appendable output;
  IView view;
  Appendable brokenAppendable;
  IView brokenView;
  IView view1;
  IView view2;

  BrokenAppendable broken;

  StringBuilder sb;

  private void init() {
    output = new StringBuilder();
    view = new View(output);
    brokenAppendable = new BrokenAppendable();
    brokenView = new View(brokenAppendable);
    this.sb = new StringBuilder();
    this.view2 = new View(this.sb);
  }

  @Test
  public void testRenderMessage1() {
    this.init();
    try {
      view.renderMessage("any, doesn't really matter!");
      assertEquals("any, doesn't really matter!", output.toString());
    }
    catch (IOException e) {
      fail();
    }
  }

  @Test
  public void testRenderMessage2() {
    this.init();
    try {
      view.renderMessage("any, doesn't really matter!");
      view.renderMessage("any any any!");
      assertEquals("any, doesn't really matter!any any any!", output.toString());
    }
    catch (IOException e) {
      fail();
    }
  }


  @Test
  public void ConstructorInit() {
    this.init();
    this.view2 = new View(this.sb);
    assertEquals("", this.sb.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void ConstructorFail() {
    this.view2 = new View(null);
  }


  @Test
  public void testRenderMessage() {
    this.init();
    assertEquals("", this.sb.toString());
    try {
      this.view2.renderMessage("Invalid input");
      assertEquals("Invalid input", this.sb.toString());
    } catch (IOException e) {
      fail();
    }
  }

  @Test(expected = IOException.class)
  public void testIOException4() throws IOException {
    this.init();
    this.brokenView.renderMessage("invalid input");
  }

  @Test
  public void testRenderMessage3() {
    this.init();
    try {
      view.renderMessage("any, doesn't really matter!");
      view.renderMessage("any any any!");
      view.renderMessage("any any any any any!");
      assertEquals("any, doesn't really matter!any any any!any any any any any!",
              output.toString());
    }
    catch (IOException e) {
      fail();
    }
  }

  @Test(expected = IOException.class)
  public void testIOException() throws IOException {
    this.init();
    brokenView.renderMessage("any, we expect an IO!");
  }

  @Test(expected = IOException.class)
  public void testIOException1() throws IOException {
    this.init();
    brokenView.renderMessage("any, any any any any any we expect an IO!");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullException() {
    IView error = new View(null);
  }
}