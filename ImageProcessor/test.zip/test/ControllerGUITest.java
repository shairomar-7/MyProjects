import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import imageprocessor.Pixel;
import imageprocessor.controller.ControllerGUI;
import imageprocessor.controller.Features;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;
import imageprocessor.view.IViewGUI;

import static org.junit.Assert.assertEquals;


/**
 * ControllerGUITest, class designated to testing the ControllerGUI class.
 */
public class ControllerGUITest {
  Features features;
  EnhancedModel model;
  ControllerGUI controller;

  private void init() {
    model = new EnhancedModelImpl(this.randomGenerator(2, 2, 255),
            2, 2);
    features = new ControllerGUI(model);
    controller = new ControllerGUI(model);
  }

  private List<List<Pixel>> randomGenerator(int width, int height, int maxDepth) {
    List<List<Pixel>> result = new ArrayList<>();

    Random rand = new Random(10);
    for (int i = 0; i < height; i++) {
      List<Pixel> inner = new ArrayList<>();
      for (int j = 0; j < width; j++) {
        inner.add(new Pixel(rand.nextInt(maxDepth), rand.nextInt(maxDepth),
                rand.nextInt(maxDepth)));
      }
      result.add(inner);
    }
    return result;
  }

  @Test
  public void testFeaturesParseInputs1() {
    this.init();
    Appendable output = new StringBuilder();
    controller.setView(new MockGUI(output));
    controller.loadImage("Images/initFlipped.ppm");
    assertEquals("Function: addFeatures\n" +
            "Function: setImage, Image properties:  width: 2, height: 2\n" +
            "Function: showHistogram; map size: 4\n", output.toString());
    controller.setCommand("sepia");
    controller.execute();
    assertEquals("Function: addFeatures\n" +
            "Function: setImage, Image properties:  width: 2, height: 2\n" +
            "Function: showHistogram; map size: 4\n" +
            "Function: setImage, Image properties:  width: 2, height: 2\n" +
            "Function: showHistogram; map size: 4\n", output.toString());
    controller.exitProgram();
  }

  @Test
  public void testMockModelParseInputs() {
    this.init();
    Appendable mockOuput = new StringBuilder();
    Appendable mockViewOuput = new StringBuilder();
    EnhancedModel model = new MockModel(mockOuput);
    IViewGUI mockGUI = new MockGUI(mockViewOuput);
    controller = new ControllerGUI(model);
    controller.setView(mockGUI);
    assertEquals("Function: addFeatures\n", mockViewOuput.toString());
    assertEquals("", mockOuput.toString());
  }

  @Test
  public void testMockViewProcessInputsFlipVertical() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(3, 75, 108),
            new Pixel(60, 151, 241));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(127, 148, 216),
            new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner_2, inner_1);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("flip-vertical");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmflip-vertical"));
  }

  @Test
  public void testMockViewProcessInputsFlipHorizontal() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(60, 151, 241),
            new Pixel(3, 75, 108));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(244, 58, 164),
            new Pixel(127, 148, 216));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("flip-horizontal");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmflip-horizontal"));
  }

  @Test
  public void testMockViewProcessInputsBrighten() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(33, 105, 138),
            new Pixel(90, 181, 255));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(157, 178, 246),
            new Pixel(255, 88, 194));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("brighten");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmbrighten"));
  }

  @Test
  public void testMockViewProcessInputsDarken() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(0, 45, 78),
            new Pixel(30, 121, 211));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(97, 118, 186),
            new Pixel(214, 28, 134));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("darken");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmdarken"));
  }

  @Test
  public void testMockViewProcessinputsLuma() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(62, 62, 62),
            new Pixel(138, 138, 138));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(148, 148, 148),
            new Pixel(105, 105, 105));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUI = new MockGUI(output);
    controller.setView(mockGUI);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("luma");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmluma"));
  }

  @Test
  public void testMockViewProcessInputsSepia() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(79, 70, 55),
            new Pixel(185, 165, 128));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(204, 182, 141),
            new Pixel(171, 152, 118));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("sepia");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmsepia"));
  }

  @Test
  public void testMockViewProcessInputsBlur() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(39, 59, 94),
            new Pixel(53, 63, 107));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(66, 63, 103),
            new Pixel(84, 56, 104));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("blur");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmblur"));
  }

  @Test
  public void testMockViewProcessInputSharpen() {
    this.init();
    List<Pixel> inner_1 = Arrays.asList(new Pixel(110, 164, 255),
            new Pixel(153, 221, 255));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(203, 219, 255),
            new Pixel(255, 151, 255));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2);
    Appendable output = new StringBuilder();
    IViewGUI mockGUi = new MockGUI(output);
    controller.setView(mockGUi);
    controller.loadImage("Images/initFlipped.ppm");
    controller.setCommand("sharpen");
    controller.execute();
    assertEquals(result, model.getPixelsFromHistory("initFlipped.ppmsharpen"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void controllerGUIConstructorException() {
    Features features = new ControllerGUI(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetViewNullException() {
    this.init();
    controller.setView(null);
  }
}