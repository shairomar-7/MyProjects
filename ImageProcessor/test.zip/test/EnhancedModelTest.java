import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import imageprocessor.Pixel;
import imageprocessor.controller.Features;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;

import static org.junit.Assert.assertEquals;

/**
 * Tester class for EnhancedModel interface.
 */
public class EnhancedModelTest extends ModelTest {
  EnhancedModel model4;
  EnhancedModel model3;
  List<List<Pixel>> pixels4;
  List<List<Pixel>> pixels3;

  @Override
  protected void init() {
    pixels = this.randomGenerator(5, 5, 255);
    model = new EnhancedModelImpl(pixels, 5, 5);
    this.pixels2 = this.randomGenerator(2, 2, 255);
    this.model2 = new EnhancedModelImpl(pixels2, 2, 2);
    this.pixels3 = this.randomGenerator(2, 2, 255);
    this.model3 = new EnhancedModelImpl(pixels3, 2, 2);
    this.pixels4 = this.randomGenerator(3, 3, 255);
    this.model4 = new EnhancedModelImpl(pixels4, 3, 3);
  }

  @Test
  public void testDownSize() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(3, 75, 108),
            new Pixel(94, 150, 229));
    List<Pixel> inner2 = Arrays.asList(new Pixel(241, 36, 161),
            new Pixel(206, 77, 159));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    model4.addToHistory(this.randomGenerator(3, 3, 255),
            "original");
    model4.downscaleImage("original", "down", 2, 2);
    assertEquals(result.size(), model4.getPixelsFromHistory("down").size());
    assertEquals(inner1.size(), model4.getPixelsFromHistory("down").get(0).size());
    assertEquals(result, model4.getPixelsFromHistory("down"));
  }

  @Test
  public void testBlur() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(39, 59, 94),
            new Pixel(53, 63, 107));
    List<Pixel> inner2 = Arrays.asList(new Pixel(66, 63, 103),
            new Pixel(84, 56, 104));
    List<List<Pixel>> dummy = Arrays.asList(inner1, inner2);
    model3.filter("blur", "initialModel", "blurry");
    assertEquals(dummy, model3.getPixelsFromHistory("blurry"));
  }

  @Test
  public void testBlur3By3() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(47, 51, 87),
            new Pixel(79, 86, 144), new Pixel(78, 70, 120));
    List<Pixel> inner2 = Arrays.asList(new Pixel(124, 53, 117),
            new Pixel(166, 88, 171), new Pixel(140, 69, 140));
    List<Pixel> inner3 = Arrays.asList(new Pixel(123, 26, 84),
            new Pixel(158, 49, 110), new Pixel(124, 39, 87));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2, inner3);
    model4.filter("blur", "initialModel", "blurry3By3");
    assertEquals(result, model4.getPixelsFromHistory("blurry3By3"));
  }

  @Test
  public void testSharpen() {
    this.init();
    List<Pixel> inner1 = Arrays.asList(new Pixel(110, 164, 255),
            new Pixel(153, 221, 255));
    List<Pixel> inner2 = Arrays.asList(new Pixel(203, 219, 255),
            new Pixel(255, 151, 255));
    List<List<Pixel>> dummy = Arrays.asList(inner1, inner2);
    model3.filter("sharpen", "initialModel", "blurry");
    assertEquals(dummy, model3.getPixelsFromHistory("blurry"));
  }

  @Test
  public void testBlurSmallerMatrix() {
    this.init();
    assertEquals(this.pixels2, model3.getPixelsFromHistory("initialModel"));

    List<Pixel> inner1 = Arrays.asList(new Pixel(39, 59, 94),
            new Pixel(53, 63, 107));
    List<Pixel> inner2 = Arrays.asList(new Pixel(66, 63, 103),
            new Pixel(84, 56, 104));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    model3.filter("blur",
            "initialModel", "initialBlur");
    assertEquals(result, model3.getPixelsFromHistory("initialBlur"));
  }

  @Test
  public void testBlurSameSizeMatrix() {
    List<Pixel> inner_1 = Arrays.asList(new Pixel(3, 75, 108),
            new Pixel(60, 151, 241), new Pixel(127, 148, 216));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(244, 58, 164),
            new Pixel(141, 108, 165),
            new Pixel(240, 61, 208));
    List<Pixel> inner_3 = Arrays.asList(new Pixel(199, 75, 113),
            new Pixel(245, 64, 149), new Pixel(215, 53, 170));
    List<List<Pixel>> pixels = Arrays.asList(inner_1, inner_2, inner_3);
    EnhancedModel em = new EnhancedModelImpl(pixels, 3, 3);
    assertEquals(pixels, em.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(47, 51, 87),
            new Pixel(79, 86, 144), new Pixel(78, 70, 120));
    List<Pixel> inner2 = Arrays.asList(new Pixel(122, 60, 113),
            new Pixel(167, 90, 174),
            new Pixel(139, 67, 145));
    List<Pixel> inner3 = Arrays.asList(new Pixel(119, 40, 77),
            new Pixel(160, 52, 116),
            new Pixel(123, 35, 97));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2, inner3);

    em.filter("blur",
            "initialModel", "initialBlur");

    assertEquals(result, em.getPixelsFromHistory("initialBlur"));
  }

  @Test
  public void testBlurLargerMatrix() {
    this.init();
    EnhancedModel em = new EnhancedModelImpl(pixels, 5, 5);
    assertEquals(pixels, em.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(53, 46, 93),
            new Pixel(88, 75, 140), new Pixel(124, 77, 137),
            new Pixel(151, 62, 124), new Pixel(107, 44, 92));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 66, 109),
            new Pixel(160, 79, 149), new Pixel(180, 92, 150),
            new Pixel(199, 105, 162), new Pixel(136, 76, 128));
    List<Pixel> inner3 = Arrays.asList(new Pixel(151, 85, 99),
            new Pixel(159, 84, 134), new Pixel(158, 119, 141),
            new Pixel(172, 164, 167), new Pixel(114, 119, 134));
    List<Pixel> inner4 = Arrays.asList(new Pixel(119, 80, 108),
            new Pixel(127, 95, 162), new Pixel(136, 129, 169),
            new Pixel(167, 165, 165), new Pixel(125, 124, 121));
    List<Pixel> inner5 = Arrays.asList(new Pixel(51, 53, 63),
            new Pixel(70, 69, 120), new Pixel(104, 74, 140),
            new Pixel(140, 84, 118), new Pixel(111, 75, 76));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2, inner3, inner4, inner5);
    em.filter("blur",
            "initialModel", "initialBlur");
    assertEquals(result, em.getPixelsFromHistory("initialBlur"));
  }


  @Test
  public void testSharpenSmallerMatrix() {
    List<Pixel> inner_1 = Arrays.asList(new Pixel(3, 75, 108),
            new Pixel(60, 151, 241));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(127, 148, 216),
            new Pixel(244, 58, 164));
    List<List<Pixel>> pixels = Arrays.asList(inner_1, inner_2);
    EnhancedModel em = new EnhancedModelImpl(pixels, 2, 2);
    assertEquals(pixels, em.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(110, 164, 255),
            new Pixel(153, 221, 255));
    List<Pixel> inner2 = Arrays.asList(new Pixel(203, 219, 255),
            new Pixel(255, 151, 255));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    em.filter("sharpen",
            "initialModel", "initialSharpen");
    assertEquals(result, em.getPixelsFromHistory("initialSharpen"));
  }

  @Test
  public void testSharpenSameSizeMatrix() {
    this.init();
    EnhancedModel em = new EnhancedModelImpl(this.pixels, 5, 5);
    assertEquals(this.pixels, em.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(40, 56, 191),
            new Pixel(118, 149, 255), new Pixel(210, 99, 255),
            new Pixel(255, 76, 242), new Pixel(224, 55, 182));
    List<Pixel> inner2 = Arrays.asList(new Pixel(255, 102, 234),
            new Pixel(255, 120, 255), new Pixel(255, 109, 223),
            new Pixel(255, 211, 255), new Pixel(255, 105, 255));
    List<Pixel> inner3 = Arrays.asList(new Pixel(255, 159, 98),
            new Pixel(250, 85, 183), new Pixel(199, 112, 102),
            new Pixel(255, 255, 255), new Pixel(107, 241, 221));
    List<Pixel> inner4 = Arrays.asList(new Pixel(227, 166, 239),
            new Pixel(221, 178, 255), new Pixel(125, 255, 255),
            new Pixel(255, 255, 255), new Pixel(255, 255, 255));
    List<Pixel> inner5 = Arrays.asList(new Pixel(51, 78, 84),
            new Pixel(61, 121, 255), new Pixel(158, 44, 255),
            new Pixel(255, 143, 221), new Pixel(255, 151, 116));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2, inner3, inner4, inner5);
    em.filter("sharpen",
            "initialModel", "initialSharpen");
    assertEquals(result, em.getPixelsFromHistory("initialSharpen"));
  }

  @Test
  public void testSharpenLargerMatrix() {
    this.init();
    List<List<Pixel>> p = this.pixels;
    List<Pixel> inner6 = Arrays.asList(new Pixel(43, 65, 19),
            new Pixel(214, 0, 12),
            new Pixel(54, 23, 109), new Pixel(85, 10, 253),
            new Pixel(100, 100, 100), new Pixel(59, 68, 71));
    p.get(0).add(new Pixel(54, 23, 14));
    p.get(1).add(new Pixel(13, 76, 49));
    p.get(2).add(new Pixel(42, 23, 59));
    p.get(3).add(new Pixel(90, 23, 141));
    p.get(4).add(new Pixel(54, 175, 211));
    p.add(inner6);
    EnhancedModel em = new EnhancedModelImpl(p, 6, 6);
    assertEquals(p, em.getPixelsFromHistory("initialModel"));
    List<Pixel> inner_1 = Arrays.asList(new Pixel(40, 56, 191),
            new Pixel(118, 149, 255), new Pixel(210, 99, 255),
            new Pixel(255, 61, 227), new Pixel(235, 77, 190),
            new Pixel(48, 10, 12));
    List<Pixel> inner_2 = Arrays.asList(new Pixel(255, 102, 234),
            new Pixel(255, 120, 255), new Pixel(255, 109, 223),
            new Pixel(255, 193, 255), new Pixel(255, 132, 255),
            new Pixel(0, 76, 69));
    List<Pixel> inner_3 = Arrays.asList(new Pixel(255, 159, 98),
            new Pixel(250, 85, 183), new Pixel(199, 112, 102),
            new Pixel(255, 255, 228), new Pixel(130, 247, 255),
            new Pixel(0, 9, 68));
    List<Pixel> inner_4 = Arrays.asList(new Pixel(188, 155, 222),
            new Pixel(171, 166, 255), new Pixel(63, 240, 236),
            new Pixel(255, 255, 230), new Pixel(255, 255, 255),
            new Pixel(57, 85, 160));
    List<Pixel> inner_5 = Arrays.asList(new Pixel(108, 92, 78),
            new Pixel(128, 142, 255), new Pixel(228, 32, 255),
            new Pixel(255, 140, 255), new Pixel(255, 239, 255),
            new Pixel(115, 211, 233));
    List<Pixel> inner_6 = Arrays.asList(new Pixel(20, 63, 0),
            new Pixel(169, 15, 0), new Pixel(78, 0, 152),
            new Pixel(138, 0, 255), new Pixel(161, 125, 172),
            new Pixel(50, 120, 71));
    List<List<Pixel>> result = Arrays.asList(inner_1, inner_2, inner_3, inner_4, inner_5,
            inner_6);
    em.filter("sharpen",
            "initialModel", "initialSharpen");
    assertEquals(result, em.getPixelsFromHistory("initialSharpen"));
  }

  @Test
  public void testTransformSepia() {
    this.init();
    assertEquals(this.pixels2, model3.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(79, 70, 55),
            new Pixel(185, 165, 128));
    List<Pixel> inner2 = Arrays.asList(new Pixel(204, 182, 141),
            new Pixel(171, 152, 118));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    model3.colorTransform("sepia",
            "initialModel", "initialSepia");
    assertEquals(result, model3.getPixelsFromHistory("initialSepia"));
  }

  @Test
  public void testTransformLuma() {
    this.init();
    assertEquals(this.pixels2, model3.getPixelsFromHistory("initialModel"));
    List<Pixel> inner1 = Arrays.asList(new Pixel(62, 62, 62),
            new Pixel(138, 138, 138));
    List<Pixel> inner2 = Arrays.asList(new Pixel(148, 148, 148),
            new Pixel(105, 105, 105));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    model3.colorTransform("luma",
            "initialModel", "initialLuma");
    assertEquals(result, model3.getPixelsFromHistory("initialLuma"));
  }

  List<List<Pixel>> pixels;
  EnhancedModel em;
  Features controller;

  @Before
  public void init2() {
    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(54, 12, 129), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(255, 0, 15));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 89, 54),
            new Pixel(54, 12, 234), new Pixel(142, 86, 100),
            new Pixel(43, 54, 12), new Pixel(255, 0, 15));
    List<Pixel> p3 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(54, 171, 185), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(19, 0, 15));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(54, 67, 131), new Pixel(234, 54, 100),
            new Pixel(43, 54, 12), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(10, 12, 14), new Pixel(19, 86, 99),
            new Pixel(43, 54, 243), new Pixel(255, 0, 15));
    this.pixels = Arrays.asList(p1, p2, p3, p4, p5);
    this.em = new EnhancedModelImpl(this.pixels, 5, 5);
  }

  @Test
  public void testDownscale() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 3, 3);

    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(47, 61, 110), new Pixel(114, 36, 13));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 186, 54),
            new Pixel(69, 97, 134), new Pixel(61, 36, 13));
    List<Pixel> p3 = Arrays.asList(new Pixel(82, 234, 54),
            new Pixel(121, 59, 97), new Pixel(114, 80, 64));

    List<List<Pixel>> result = Arrays.asList(p1, p2, p3);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }


  @Test
  public void testDownscaleGreaterWidth() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 2, 3);

    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(47, 61, 110), new Pixel(114, 36, 13));
    List<Pixel> p2 = Arrays.asList(new Pixel(72, 234, 54),
            new Pixel(110, 86, 119), new Pixel(74, 69, 13));

    List<List<Pixel>> result = Arrays.asList(p1, p2);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }

  @Test
  public void testDownscaleGreaterHeight() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 3, 2);
    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(43, 70, 56));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 186, 54),
            new Pixel(60, 70, 56));
    List<Pixel> p3 = Arrays.asList(new Pixel(82, 234, 54),
            new Pixel(103, 59, 94));
    List<List<Pixel>> result = Arrays.asList(p1, p2, p3);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }

  @Test (expected = IllegalArgumentException.class)
  public void testDownScaleException() {
    this.em.downscaleImage("initialModel", "initDownscale", 6, 6);
  }
}
