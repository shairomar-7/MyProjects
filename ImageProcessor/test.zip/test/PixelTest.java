import org.junit.Before;
import org.junit.Test;
import imageprocessor.Pixel;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Class designated for testing the Pixels class.
 */
public class PixelTest {
  Pixel p1;
  Pixel p2;
  Pixel p3;
  Pixel p4;
  Pixel p5;


  @Before
  public void init() {
    this.p1 = new Pixel(120, 120, 120);
    this.p2 = new Pixel(0, 13, 255);
    this.p3 = new Pixel(255, 255, 255);
    this.p4 = new Pixel(0, 43, 0);
    this.p5 = new Pixel(53, 87, 213);
  }

  @Test
  public void testConstructor() {
    this.p1 = new Pixel(120, 120, 120);
    this.p2 = new Pixel(0, 13, 255);
    this.p3 = new Pixel(255, 255, 255);
    this.p4 = new Pixel(0, 43, 0);
    this.p5 = new Pixel(53, 87, 213);

    assertEquals(new Pixel(120, 120, 120), this.p1.executeCommand("r"));
    assertEquals(new Pixel(0, 0, 0), this.p2.executeCommand("r"));
    assertEquals(new Pixel(0, 0, 0), this.p2.executeCommand("r"));
    assertEquals(new Pixel(43, 43, 43), this.p4.executeCommand("g"));
    assertEquals(new Pixel(213, 213, 213), this.p5.executeCommand("b"));
    assertEquals(new Pixel(53, 53, 53), this.p5.executeCommand("r"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void redNegative() {
    Pixel p = new Pixel(-1, 255, 43);
  }

  @Test(expected = IllegalArgumentException.class)
  public void greenNegative() {
    Pixel p = new Pixel(14, -4, 43);
  }

  @Test(expected = IllegalArgumentException.class)
  public void blueNegative() {
    Pixel p = new Pixel(100, 121, -10);
  }


  @Test
  public void testExecuteCommand() {
    assertEquals(new Pixel(88, 88, 88), this.p5.executeCommand("luma"));
    assertEquals(new Pixel(117, 117, 117), this.p5.executeCommand("intensity"));
    assertEquals(new Pixel(213, 213, 213), this.p5.executeCommand("value"));
    assertEquals(new Pixel(53, 53, 53), this.p5.executeCommand("r"));
    assertEquals(new Pixel(87, 87, 87), this.p5.executeCommand("g"));
    assertEquals(new Pixel(213, 213, 213), this.p5.executeCommand("b"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorException() {
    this.p1.executeCommand("e");
  }

  @Test
  public void testIncrementPixel() {
    assertEquals(new Pixel(63, 97, 223),
            this.p5.incrementPixel(10, 255));
    assertEquals(new Pixel(0, 0, 113),
            this.p5.incrementPixel(-100, 255));
    assertEquals(new Pixel(153, 187, 255),
            this.p5.incrementPixel(100, 255));
    assertEquals(new Pixel(33, 67, 193),
            this.p5.incrementPixel(-20, 255));
  }

  @Test
  public void testEquals() {
    assertTrue(this.p1.equals(new Pixel(120, 120, 120)));
    assertFalse(this.p5.equals(new Pixel(43, 12, 43)));
  }

  @Test
  public void testHashCode() {
    assertEquals(148951, this.p1.hashCode());
    assertEquals(30449, this.p2.hashCode());
    assertEquals(283006, this.p3.hashCode());
    assertEquals(31124, this.p4.hashCode());
    assertEquals(83634, this.p5.hashCode());
  }

  @Test
  public void testClamp() {
    this.init();
    assertEquals(new Pixel(255, 255, 2), new Pixel(255, 256, 2).clamp());
    assertEquals(new Pixel(255, 255, 0), new Pixel(300, 255, 0).clamp());
  }

  @Test
  public void testGetComponent() {
    assertEquals(53,
            this.p5.getComponent(0));
    assertEquals(87,
            this.p5.getComponent(1));
    assertEquals(213,
            this.p5.getComponent(2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNegativeComponent() {
    this.p5.getComponent(-2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOutOfRangeComponent() {
    this.p5.getComponent(13);
  }
}