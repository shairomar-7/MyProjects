import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import imageprocessor.controller.Controller;
import imageprocessor.controller.commands.Brighten;
import imageprocessor.controller.commands.Flip;
import imageprocessor.controller.commands.ImageCommand;
import imageprocessor.controller.commands.Visualize;
import imageprocessor.controller.IController;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;
import imageprocessor.Pixel;
import imageprocessor.view.IView;
import imageprocessor.view.View;

import static org.junit.Assert.assertEquals;

/**
 * Class designated for testing the ImageCommand's subclasses.
 */
public class CommandsTest {

  List<List<Pixel>> pixels;
  EnhancedModel model;
  List<List<Pixel>> pixels2;
  EnhancedModel model2;
  EnhancedModel model3;


  IView v;

  IController c;

  ArrayList<ArrayList<Pixel>> result;
  ArrayList<Pixel> inner1;
  ArrayList<Pixel> inner2;

  @Before
  public void init() {
    pixels = this.randomGenerator(5, 5, 255);
    model = new EnhancedModelImpl(pixels, 5, 5);
    this.pixels2 = this.randomGenerator(2, 2, 255);
    this.model2 = new EnhancedModelImpl(pixels2, 2, 2);
    this.model3 = new EnhancedModelImpl();
    this.v = new View();
    this.c = new Controller(this.model2, this.v);

    this.result = new ArrayList<ArrayList<Pixel>>();
    this.inner1 = new ArrayList<Pixel>();
    this.inner1.add(new Pixel(3, 75, 108));
    this.inner1.add(new Pixel(60, 151, 241));
    this.inner2 = new ArrayList<Pixel>();
    this.inner2.add(new Pixel(127, 148, 216));
    this.inner2.add(new Pixel(244, 58, 164));
    this.result.add(inner1);
    this.result.add(inner2);
  }


  private List<List<Pixel>> randomGenerator(int width, int height, int maxDepth) {
    List<List<Pixel>> result = new ArrayList<>();

    Random rand = new Random(10);
    for (int i = 0; i < height; i++) {
      List<Pixel> inner = new ArrayList<>();
      for (int j = 0; j < width; j++) {
        inner.add(new Pixel(rand.nextInt(maxDepth),
                rand.nextInt(maxDepth), rand.nextInt(maxDepth)));
      }
      result.add(inner);
    }
    //System.out.println(result);
    return result;
  }

  @Test
  public void testFlip() {
    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand flip = new Flip("initialModel", "initFlip", true);

    flip.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(this.result.get(0).get(1));
    result2.get(0).add(this.result.get(0).get(0));
    result2.get(1).add(this.result.get(1).get(1));
    result2.get(1).add(this.result.get(1).get(0));
    assertEquals(result2, this.model2.getPixelsFromHistory("initFlip"));
    ImageCommand flip2 = new Flip("initFlip", "initVert", false);

    flip2.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result3 = new ArrayList<ArrayList<Pixel>>();
    result3.add(new ArrayList<Pixel>());
    result3.add(new ArrayList<Pixel>());
    result3.get(0).add(result2.get(1).get(0));
    result3.get(0).add(result2.get(1).get(1));
    result3.get(1).add(result2.get(0).get(0));
    result3.get(1).add(result2.get(0).get(1));
    assertEquals(result3, this.model2.getPixelsFromHistory("initVert"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidArgExecute() {
    ImageCommand flip = new Flip("initialModl", "initFlip", true);

    flip.execute(this.model2);
  }


  @Test
  public void testRedComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand red = new Visualize("initialModel",
            "redScale", "r");

    red.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(3, 3, 3));
    result2.get(0).add(new Pixel(60, 60, 60));
    result2.get(1).add(new Pixel(127, 127, 127));
    result2.get(1).add(new Pixel(244, 244, 244));
    assertEquals(result2, this.model2.getPixelsFromHistory("redScale"));
  }

  @Test
  public void testGreenComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand green = new Visualize("initialModel",
            "greenScale", "g");

    green.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(75, 75, 75));
    result2.get(0).add(new Pixel(151, 151, 151));
    result2.get(1).add(new Pixel(148, 148, 148));
    result2.get(1).add(new Pixel(58, 58, 58));
    assertEquals(result2, this.model2.getPixelsFromHistory("greenScale"));
  }

  @Test
  public void testBlueComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand blue = new Visualize("initialModel",
            "blueScale", "b");

    blue.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(108, 108, 108));
    result2.get(0).add(new Pixel(241, 241, 241));
    result2.get(1).add(new Pixel(216, 216, 216));
    result2.get(1).add(new Pixel(164, 164, 164));
    assertEquals(result2, this.model2.getPixelsFromHistory("blueScale"));
  }

  @Test
  public void testIntensityComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand inten = new Visualize("initialModel",
            "intensity", "intensity");

    inten.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(62, 62, 62));
    result2.get(0).add(new Pixel(150, 150, 150));
    result2.get(1).add(new Pixel(163, 163, 163));
    result2.get(1).add(new Pixel(155, 155, 155));
    assertEquals(result2, this.model2.getPixelsFromHistory("intensity"));
  }

  @Test
  public void testLumaComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand red = new Visualize("initialModel",
            "luma", "luma");

    red.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(62, 62, 62));
    result2.get(0).add(new Pixel(138, 138, 138));
    result2.get(1).add(new Pixel(148, 148, 148));
    result2.get(1).add(new Pixel(105, 105, 105));
    assertEquals(result2, this.model2.getPixelsFromHistory("luma"));
  }


  @Test
  public void testValueComponent() {

    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand red = new Visualize("initialModel",
            "value", "value");

    red.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(108, 108, 108));
    result2.get(0).add(new Pixel(241, 241, 241));
    result2.get(1).add(new Pixel(216, 216, 216));
    result2.get(1).add(new Pixel(244, 244, 244));
    assertEquals(result2, this.model2.getPixelsFromHistory("value"));
  }

  @Test
  public void testBrighten() {
    assertEquals(result, this.model2.getPixelsFromHistory("initialModel"));
    ImageCommand bright = new Brighten(10, "initialModel",
            "increase");

    bright.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result2 = new ArrayList<ArrayList<Pixel>>();
    result2.add(new ArrayList<Pixel>());
    result2.add(new ArrayList<Pixel>());
    result2.get(0).add(new Pixel(13, 85, 118));
    result2.get(0).add(new Pixel(70, 161, 251));
    result2.get(1).add(new Pixel(137, 158, 226));
    result2.get(1).add(new Pixel(254, 68, 174));
    assertEquals(result2, this.model2.getPixelsFromHistory("increase"));

    ImageCommand bright2 = new Brighten(-10, "initialModel",
            "decrease");

    bright2.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result3 = new ArrayList<ArrayList<Pixel>>();
    result3.add(new ArrayList<Pixel>());
    result3.add(new ArrayList<Pixel>());
    result3.get(0).add(new Pixel(0, 65, 98));
    result3.get(0).add(new Pixel(50, 141, 231));
    result3.get(1).add(new Pixel(117, 138, 206));
    result3.get(1).add(new Pixel(234, 48, 154));
    assertEquals(result3, this.model2.getPixelsFromHistory("decrease"));

    ImageCommand bright3 = new Brighten(-300, "initialModel",
            "zero");

    bright3.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result4 = new ArrayList<ArrayList<Pixel>>();
    result4.add(new ArrayList<Pixel>());
    result4.add(new ArrayList<Pixel>());
    result4.get(0).add(new Pixel(0, 0, 0));
    result4.get(0).add(new Pixel(0, 0, 0));
    result4.get(1).add(new Pixel(0, 0, 0));
    result4.get(1).add(new Pixel(0, 0, 0));
    assertEquals(result4, this.model2.getPixelsFromHistory("zero"));

    ImageCommand bright4 = new Brighten(300, "initialModel",
            "max");

    bright4.execute(this.model2);
    ArrayList<ArrayList<Pixel>> result5 = new ArrayList<ArrayList<Pixel>>();
    result5.add(new ArrayList<Pixel>());
    result5.add(new ArrayList<Pixel>());
    result5.get(0).add(new Pixel(255, 255, 255));
    result5.get(0).add(new Pixel(255, 255, 255));
    result5.get(1).add(new Pixel(255, 255, 255));
    result5.get(1).add(new Pixel(255, 255, 255));
    assertEquals(result5, this.model2.getPixelsFromHistory("max"));
  }
}
