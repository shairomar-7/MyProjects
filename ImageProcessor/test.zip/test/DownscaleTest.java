import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import imageprocessor.Pixel;
import imageprocessor.controller.Features;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;

import static org.junit.Assert.assertEquals;

/**
 * Tests for the downscale operation.
 */
public class DownscaleTest {
  List<List<Pixel>> pixels;
  EnhancedModel em;
  Features controller;

  @Before
  public void init2() {
    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
        new Pixel(54, 12, 129), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(255, 0, 15));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 89, 54),
            new Pixel(54, 12, 234), new Pixel(142, 86, 100),
            new Pixel(43, 54, 12), new Pixel(255, 0, 15));
    List<Pixel> p3 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(54, 171, 185), new Pixel(43, 86, 100),
            new Pixel(43, 54, 12), new Pixel(19, 0, 15));
    List<Pixel> p4 = Arrays.asList(new Pixel(101, 234, 54),
            new Pixel(54, 67, 131), new Pixel(234, 54, 100),
            new Pixel(43, 54, 12), new Pixel(255, 199, 15));
    List<Pixel> p5 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(10, 12, 14), new Pixel(19, 86, 99),
            new Pixel(43, 54, 243), new Pixel(255, 0, 15));
    this.pixels = Arrays.asList(p1, p2, p3, p4, p5);
    this.em = new EnhancedModelImpl(this.pixels, 5, 5);
  }

  @Test
  public void testDownscale() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 3, 3);

    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(47, 61, 110), new Pixel(114, 36, 13));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 186, 54),
            new Pixel(69, 97, 134), new Pixel(61, 36, 13));
    List<Pixel> p3 = Arrays.asList(new Pixel(82, 234, 54),
            new Pixel(121, 59, 97), new Pixel(114, 80, 64));

    List<List<Pixel>> result = Arrays.asList(p1, p2, p3);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }


  @Test
  public void testDownscaleGreaterWidth() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 2, 3);

    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(47, 61, 110), new Pixel(114, 36, 13));
    List<Pixel> p2 = Arrays.asList(new Pixel(72, 234, 54),
            new Pixel(110, 86, 119), new Pixel(74, 69, 13));

    List<List<Pixel>> result = Arrays.asList(p1, p2);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }

  @Test
  public void testDownscaleGreaterHeight() {
    assertEquals(this.pixels, this.em.getPixelsFromHistory("initialModel"));
    this.em.downscaleImage("initialModel", "initDownscale", 3, 2);

    List<Pixel> p1 = Arrays.asList(new Pixel(43, 234, 54),
            new Pixel(43, 70, 56));
    List<Pixel> p2 = Arrays.asList(new Pixel(43, 186, 54),
            new Pixel(60, 70, 56));
    List<Pixel> p3 = Arrays.asList(new Pixel(82, 234, 54),
            new Pixel(103, 59, 94));

    List<List<Pixel>> result = Arrays.asList(p1, p2, p3);
    assertEquals(result, this.em.getPixelsFromHistory("initDownscale"));
  }

  @Test (expected = IllegalArgumentException.class)
  public void testDownScaleException() {
    this.em.downscaleImage("initialModel", "initDownscale", 6, 6);
  }
}
