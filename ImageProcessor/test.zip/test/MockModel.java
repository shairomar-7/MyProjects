import java.io.IOException;
import java.util.List;

import imageprocessor.model.EnhancedModel;
import imageprocessor.Pixel;

/**
 * Mock model; used for testing purposes.
 * This class is used to test that the Model is indeed receiving the expected inputs that the
 * controller receives and gives to its model field. The MockModel basically works by implementing
 * the model interface that is also implemented by the Model class, and is constructed by giving it
 * an Appendable, that will tell us what the Model is receiving as inputs,
 * in a string representation.
 */
public class MockModel implements EnhancedModel {
  Appendable output;

  /**
   * Mock Model, imposter Model is constructed with the given output destination.
   *
   * @param output Appendable represents the destination of the output
   * @throws IllegalArgumentException if the given output is null.
   */
  MockModel(Appendable output) throws IllegalArgumentException {
    if (output == null) {
      throw new IllegalArgumentException("Given output must be non-null!");
    }
    this.output = output;
  }

  @Override
  public void addToHistory(List<List<Pixel>> pixels, String imageName) {
    try {
      this.output.append("Function: addToHistory -> imageName: " + imageName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public void flip(boolean horizontalHuh, String fileName, String destName) {
    try {
      this.output.append("Function: flip -> " + horizontalHuh + ", " + fileName + ", " + destName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public void visualizeComponent(String component, String fileName, String destName)
          throws IllegalStateException {
    try {
      this.output.append("Function: visualizeComponent -> "
              + component + ", " + fileName + ", " + destName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public void brightenOrDarkenBy(int increment, String fileName, String destName)
          throws IllegalStateException {
    try {
      this.output.append("Function: brightenOrDarkenBy -> "
              + increment + ", " + fileName + ", " + destName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public int getDepth() {
    return 0;
  }

  @Override
  public List<List<Pixel>> getPixelsFromHistory(String fileName) {
    try {
      this.output.append("Function: getPixelsFromHistory -> " + fileName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
    return null;
  }

  @Override
  public void colorTransform(String transformMethod, String imageName, String destName) {
    try {
      this.output.append("Function: colorTransform -> " + transformMethod + ", " + imageName
              + ", " + destName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public void filter(String filterMethod, String imageName, String destName) {
    try {
      this.output.append("Function: filter -> " + filterMethod + ", " + imageName
              + ", " + destName);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }

  @Override
  public void downscaleImage(String imageName, String destName, int height, int width) {
    try {
      this.output.append("Function: downscaleImage -> " + imageName
              + ", " + destName + ", " + height + ", " + width);
    } catch (IOException e) {
      throw new IllegalArgumentException("Hmm something went wrong, unexpect IO exception!");
    }
  }
}
