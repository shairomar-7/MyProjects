package commandstest;

/**
 * Test for luma-transformed jpg image.
 */
public class LumaExecuteJPG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpg initialModel" +
            " luma initialModel initialLumaJPG"
            + " save res/initialLuma.jpg initialLumaJPG q";
  }

  @Override
  protected String getDestName() {
    return "initialLumaJPG";
  }
}
