package commandstest;

/**
 * Test for sepia-transformed ppm image.
 */
public class SepiaExecutePPM extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.ppm initialModel" +
            " sepia initialModel initialSepiaPPM"
            + " save res/initialSepia.ppm initialSepiaPPM q";
  }

  @Override
  protected String getDestName() {
    return "initialSepiaPPM";
  }
}
