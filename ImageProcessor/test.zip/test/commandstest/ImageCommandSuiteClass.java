package commandstest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Suite class for image commands test.
 */
public class ImageCommandSuiteClass {

  /**
   * All the tests in the suite class.
   */
  @RunWith(Suite.class)

  @Suite.SuiteClasses( {
          LumaExecutePPM.class,
          LumaExecuteBMP.class,
          LumaExecuteJPEG.class,
          LumaExecuteJPG.class,
          LumaExecutePNG.class,
          SepiaExecuteBMP.class,
          SepiaExecuteJPEG.class,
          SepiaExecuteJPG.class,
          SepiaExecutePNG.class,
          SepiaExecutePPM.class,
          BlurExecuteBMP.class,
          BlurExecuteJPEG.class,
          BlurExecuteJPG.class,
          BlurExecutePNG.class,
          BlurExecutePPM.class,
          SharpenExecuteBMP.class,
          SharpenExecuteJPEG.class,
          SharpenExecuteJPG.class,
          SharpenExecutePNG.class,
          SharpenExecutePPM.class

      }

  )

  public class StringAccumulatorSuite {
  }
}
