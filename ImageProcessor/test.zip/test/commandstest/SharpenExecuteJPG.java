package commandstest;

/**
 * Test for sharpened jpg image.
 */
public class SharpenExecuteJPG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpg initialModel" +
            " sharpen initialModel initialSharpenJPG"
            + " save res/initialSharpen.jpg initialSharpenJPG q";
  }

  @Override
  protected String getDestName() {
    return "initialSharpenJPG";
  }
}