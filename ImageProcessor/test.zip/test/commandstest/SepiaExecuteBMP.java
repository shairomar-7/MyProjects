package commandstest;

/**
 * Test for sepia-transformed bmp image.
 */
public class SepiaExecuteBMP extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.bmp initialModel" +
            " sepia initialModel initialSepiaBMP"
            + " save res/initialSepia.bmp initialSepiaBMP q";
  }

  @Override
  protected String getDestName() {
    return "initialSepiaBMP";
  }
}

