package commandstest;

/**
 * Test for sharpened jpeg image.
 */
public class SharpenExecuteJPEG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpeg initialModel" +
            " sharpen initialModel initialSharpenJPEG"
            + " save res/initialSharpen.jpeg initialSharpenJPEG q";
  }

  @Override
  protected String getDestName() {
    return "initialSharpenJPEG";
  }
}