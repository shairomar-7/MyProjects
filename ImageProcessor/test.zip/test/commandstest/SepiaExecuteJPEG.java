package commandstest;

/**
 * Test for sepia-transformed jpeg image.
 */
public class SepiaExecuteJPEG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpeg initialModel" +
            " sepia initialModel initialSepiaJPEG"
            + " save res/initialSepia.jpeg initialSepiaJPEG q";
  }

  @Override
  protected String getDestName() {
    return "initialSepiaJPEG";
  }
}
