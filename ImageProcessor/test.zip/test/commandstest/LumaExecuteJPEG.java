package commandstest;

/**
 * Test for luma-transformed jpeg image.
 */
public class LumaExecuteJPEG extends AbstractExecuteTests {

  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpeg initialModel" +
            " luma initialModel initialLumaJPEG"
            + " save res/initialLuma.jpeg initialLumaJPEG q";
  }

  @Override
  protected String getDestName() {
    return "initialLumaJPEG";
  }
}
