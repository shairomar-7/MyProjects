package commandstest;

/**
 * Test for sharpened bmp image.
 */
public class SharpenExecuteBMP extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.bmp initialModel" +
            " sharpen initialModel initialSharpenBMP"
            + " save res/initialSharpen.bmp initialSharpenBMP q";
  }

  @Override
  protected String getDestName() {
    return "initialSharpenBMP";
  }
}

