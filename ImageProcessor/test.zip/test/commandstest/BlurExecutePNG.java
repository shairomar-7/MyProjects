package commandstest;

/**
 * Test for blurred png image.
 */
public class BlurExecutePNG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.png initialModel" +
            " blur initialModel initialBlurPNG"
            + " save res/initialBlur.png initialBlurPNG q";
  }

  @Override
  protected String getDestName() {
    return "initialBlurPNG";
  }
}
