package commandstest;

/**
 * Test for blurred jpeg image.
 */
public class BlurExecuteJPEG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpeg initialModel" +
            " blur initialModel initialBlurJPEG"
            + " save res/initialBlur.jpeg initialBlurJPEG q";
  }

  @Override
  protected String getDestName() {
    return "initialBlurJPEG";
  }
}
