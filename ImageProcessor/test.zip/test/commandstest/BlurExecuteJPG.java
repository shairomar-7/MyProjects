package commandstest;

/**
 * Test for blurred jpg image.
 */
public class BlurExecuteJPG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpg initialModel" +
            " blur initialModel initialBlurJPG"
            + " save res/initialBlur.jpg initialBlurJPG q";
  }

  @Override
  protected String getDestName() {
    return "initialBlurJPG";
  }
}
