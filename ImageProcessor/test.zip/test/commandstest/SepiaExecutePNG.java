package commandstest;

/**
 * Test for sepia-transformed png image.
 */
public class SepiaExecutePNG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.png initialModel" +
            " sepia initialModel initialSepiaPNG"
            + " save res/initialSepia.png initialSepiaPNG q";
  }

  @Override
  protected String getDestName() {
    return "initialSepiaPNG";
  }
}

