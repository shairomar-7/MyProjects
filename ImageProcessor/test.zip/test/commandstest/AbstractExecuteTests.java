package commandstest;

import org.junit.Before;
import org.junit.Test;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import imageprocessor.Pixel;
import imageprocessor.controller.Controller;
import imageprocessor.model.EnhancedModel;
import imageprocessor.model.EnhancedModelImpl;
import imageprocessor.view.IView;
import imageprocessor.view.View;

import static org.junit.Assert.assertEquals;

/**
 * Abstract test class for all the image commands in the controller package.
 */
public abstract class AbstractExecuteTests {

  List<List<Pixel>> pixels;
  EnhancedModel m;
  IView v;
  private List<List<Pixel>> result;

  @Before
  public void init() {
    List<Pixel> inner1 = Arrays.asList(new Pixel(3, 75, 108), new Pixel(60, 151, 241));
    List<Pixel> inner2 = Arrays.asList(new Pixel(127, 148, 216), new Pixel(244, 58, 164));
    List<List<Pixel>> result = Arrays.asList(inner1, inner2);
    this.pixels = result;
    this.m = new EnhancedModelImpl(pixels, 2, 2);
    this.v = new View();
  }

  @Test
  public void abstractExecute() {
    Readable r = new StringReader(this.getFilePath());

    this.determineType();

    assertEquals(this.pixels, this.m.getPixelsFromHistory("initialModel"));
    Controller c = new Controller(this.m, this.v, r);
    c.goImageProcessor();

    assertEquals(result, this.m.getPixelsFromHistory(this.getDestName()));
  }

  private void determineType() {
    if (this.getFilePath().contains("Luma")) {
      List<Pixel> inner1 = Arrays.asList(new Pixel(62, 62, 62), new Pixel(138, 138, 138));
      List<Pixel> inner2 = Arrays.asList(new Pixel(148, 148, 148), new Pixel(105, 105, 105));
      this.result = Arrays.asList(inner1, inner2);
    }
    else if (this.getFilePath().contains("Sepia")) {
      List<Pixel> inner1 = Arrays.asList(new Pixel(79, 70, 55), new Pixel(185, 165, 128));
      List<Pixel> inner2 = Arrays.asList(new Pixel(204, 182, 141), new Pixel(171, 152, 118));
      this.result = Arrays.asList(inner1, inner2);
    }
    else if (this.getFilePath().contains("Blur")) {
      List<Pixel> inner1 = Arrays.asList(new Pixel(39, 59, 94), new Pixel(53, 63, 107));
      List<Pixel> inner2 = Arrays.asList(new Pixel(66, 63, 103), new Pixel(84, 56, 104));
      this.result = Arrays.asList(inner1, inner2);
    }
    else {

      List<Pixel> inner1 = Arrays.asList(new Pixel(110, 164, 255),
              new Pixel(153, 221, 255));
      List<Pixel> inner2 = Arrays.asList(new Pixel(203, 219, 255), new Pixel(255, 151, 255));
      this.result = Arrays.asList(inner1, inner2);
    }
  }

  protected abstract String getFilePath();

  protected abstract String getDestName();

}
