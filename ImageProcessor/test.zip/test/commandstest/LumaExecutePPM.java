package commandstest;

/**
 * Test for luma-transformed ppm image.
 */
public class LumaExecutePPM extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.ppm initialModel" +
            " luma initialModel initialLumaPPM"
            + " save res/initialLuma.ppm initialLumaPPM q";
  }

  @Override
  protected String getDestName() {
    return "initialLumaPPM";
  }
}


