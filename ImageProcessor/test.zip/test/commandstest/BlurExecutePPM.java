package commandstest;

/**
 * Test for blurred ppm image.
 */
public class BlurExecutePPM extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.ppm initialModel" +
            " blur initialModel initialBlurPPM"
            + " save res/initialBlur.ppm initialBlurPPM q";
  }

  @Override
  protected String getDestName() {
    return "initialBlurPPM";
  }
}
