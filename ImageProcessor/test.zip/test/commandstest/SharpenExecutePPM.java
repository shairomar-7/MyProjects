package commandstest;

/**
 * Test for sharpened ppm image.
 */
public class SharpenExecutePPM extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.ppm initialModel" +
            " sharpen initialModel initialSharpenPPM"
            + " save res/initialSharpen.ppm initialSharpenPPM q";
  }

  @Override
  protected String getDestName() {
    return "initialSharpenPPM";
  }
}
