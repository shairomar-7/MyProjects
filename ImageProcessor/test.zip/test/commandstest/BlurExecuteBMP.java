package commandstest;

/**
 * Test for blurred bmp image.
 */
public class BlurExecuteBMP extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.bmp initialModel" +
            " blur initialModel initialBlurBMP"
            + " save res/initialBlur.bmp initialBlurBMP q";
  }

  @Override
  protected String getDestName() {
    return "initialBlurBMP";
  }
}
