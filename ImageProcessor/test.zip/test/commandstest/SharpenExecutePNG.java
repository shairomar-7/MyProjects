package commandstest;

/**
 * Test for sharpened png image.
 */
public class SharpenExecutePNG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.png initialModel" +
            " sharpen initialModel initialSharpenPNG"
            + " save res/initialSharpen.png initialSharpenPNG q";
  }

  @Override
  protected String getDestName() {
    return "initialSharpenPNG";
  }
}