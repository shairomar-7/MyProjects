package commandstest;

/**
 * Test for sepia-transformed jpg image.
 */
public class SepiaExecuteJPG extends AbstractExecuteTests {
  @Override
  protected String getFilePath() {
    return "load res/initialModel.jpg initialModel" +
            " sepia initialModel initialSepiaJPG"
            + " save res/initialSepia.jpg initialSepiaJPG q";
  }

  @Override
  protected String getDestName() {
    return "initialSepiaJPG";
  }
}
