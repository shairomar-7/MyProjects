package commandstest;

/**
 * Test for luma-transformed bmp image.
 */
public class LumaExecuteBMP extends AbstractExecuteTests {
  @Override
    protected String getFilePath() {
    return "load res/initialModel.bmp initialModel" +
              " luma initialModel initialLumaBMP"
              + " save res/initialLuma.bmp initialLumaBMP q";
  }

  @Override
  protected String getDestName() {
    return "initialLumaBMP";
  }
}
