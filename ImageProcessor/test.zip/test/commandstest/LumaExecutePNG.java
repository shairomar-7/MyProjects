package commandstest;

/**
 * Test for luma-transformed png image.
 */
public class LumaExecutePNG extends AbstractExecuteTests {

  @Override
  protected String getFilePath() {
    return "load res/initialModel.png initialModel" +
            " luma initialModel initialLumaPNG"
            + " save res/initialLuma.png initialLumaPNG q";
  }

  @Override
  protected String getDestName() {
    return "initialLumaPNG";
  }
}
